package project.ui;

import project.model.EnumPozice;
import project.model.Record;
import project.sprava.RegionManager;

import javax.swing.*;

import java.awt.*;

/**
 * GUI для управления областями данных
 */
public class DataManagerGUI extends JFrame {

    private final RegionManager regionManager = new RegionManager();

    private final JTextArea outputArea = new JTextArea(15, 50);
    private final JTextField idField = new JTextField(10);
    private final JTextField nameField = new JTextField(15);
    private final JTextField capacityField = new JTextField(5);

    public DataManagerGUI() {
        super("Data Regions Manager");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Панель ввод
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("Input Data"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("ID:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 1;
        inputPanel.add(capacityField, gbc);

        add(inputPanel, BorderLayout.NORTH);

        // Панель кнопок
        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        buttonPanel.setBorder(BorderFactory.createTitledBorder("Actions"));

        JButton initBtn = new JButton("Init Region");
        JButton insertBtn = new JButton("Insert Record");
        JButton removeBtn = new JButton("Remove Record");
        JButton showBtn = new JButton("Show All");
        JButton clearBtn = new JButton("Clear All");
        JButton exitBtn = new JButton("Exit");

        buttonPanel.add(initBtn);
        buttonPanel.add(insertBtn);
        buttonPanel.add(removeBtn);
        buttonPanel.add(showBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(exitBtn);

        add(buttonPanel, BorderLayout.CENTER);

        // Панель вывода
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Output"));
        add(scrollPane, BorderLayout.SOUTH);

        // Действия кнопок
        initBtn.addActionListener(e -> initRegions());
        insertBtn.addActionListener(e -> insertRecord());
        removeBtn.addActionListener(e -> removeRecord());
        showBtn.addActionListener(e -> showAll());
        clearBtn.addActionListener(e -> clearAll());
        exitBtn.addActionListener(e -> System.exit(0));

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void initRegions() {
        try {
            int cap = Integer.parseInt(capacityField.getText());
            regionManager.init(cap);
            outputArea.append("Initialized with capacity " + cap + "\n");
        } catch (Exception e) {
            outputArea.append("Error: " + e.getMessage() + "\n");
        }
    }

    private void insertRecord() {
        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            Record record = new Record(id, name);
            regionManager.addRecord(record);
            outputArea.append("Inserted record: " + record + "\n");
        } catch (Exception e) {
            outputArea.append("Error: " + e.getMessage() + "\n");
        }
    }

    private void removeRecord() {
        try {
            regionManager.removeRecord(EnumPozice.FIRST);
            outputArea.append("Removed first record.\n");
        } catch (Exception e) {
            outputArea.append("Error: " + e.getMessage() + "\n");
        }
    }

    private void showAll() {
        outputArea.append("Contents of all regions:\n");
        outputArea.append(regionManager.toString() + "\n");
    }

    private void clearAll() {
        regionManager.clear();
        outputArea.append("All cleared.\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DataManagerGUI::new);
    }
}