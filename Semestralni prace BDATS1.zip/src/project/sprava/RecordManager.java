package project.sprava;

import project.list.AbstrDoubleList;
import project.model.EnumPozice;
import project.model.Record;
import project.model.EnumPozice;

import static project.model.EnumPozice.*;

public class RecordManager {
    private final AbstrDoubleList<Record> records = new AbstrDoubleList<>();

    // Вставить запись на указанную позицию (FIRST, LAST, NEXT, PREVIOUS)
    public void insertRecord(Record record, EnumPozice  position) {
        switch (position) {
            case FIRST:
                records.insertFirst(record);
                break;
            case LAST:
                records.insertLast(record);
                break;
            case NEXT:
                records.insertAfterCurrent(record);
                break;
            case PREVIOUS:
                records.insertBeforeCurrent(record);
                break;
            default:
                throw new IllegalArgumentException("Неизвестная позиция");
        }
    }

    // Получить запись по выбранной позиции
    public Record accessRecord(EnumPozice  position) {
        switch (position) {
            case FIRST:
                return records.accessFirst();
            case LAST:
                return records.accessLast();
            case NEXT:
                return records.accessNext();
            case PREVIOUS:
                return records.accessPrevious();
            default:
                throw new IllegalArgumentException("Неизвестная позиция");
        }
    }

    // Удалить запись с указанной позиции
    public Record removeRecord(EnumPozice  position) {
        switch (position) {
            case FIRST:
                return records.removeFirst();
            case LAST:
                return records.removeLast();
            case NEXT:
                return records.removeNext();
            case PREVIOUS:
                return records.removePrevious();
            default:
                throw new IllegalArgumentException("Неизвестная позиция");
        }
    }

    // Очистка всего списка записей
    public void clear() {
        records.clear();
    }
}
