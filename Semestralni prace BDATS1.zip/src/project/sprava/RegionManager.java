package project.sprava;

import project.list.AbstrDoubleList;
import project.model.Region;
import project.model.Record;
import project.model.EnumPozice;
import project.tab.RecordTable;

/**
 * Класс для управления регионами и записями.
 */
public class RegionManager {

    private final AbstrDoubleList<Region> regions = new AbstrDoubleList<>();
    private int maxRegionCapacity;

    private RecordTable recordTree = new RecordTable(); // таблица всех записей

    // инициализация с первой областью
    public void init(int maxCapacity) {
        this.maxRegionCapacity = maxCapacity;
        regions.insertFirst(new Region(1, maxCapacity));
    }

    // добавление записи в первую свободную область
    public void addRecord(Record record) {
        if (record == null) throw new IllegalArgumentException("Запись не может быть нулевой");

        for (Region r : regions) {
            if (!r.isFull()) {
                r.addRecord(record);
                recordTree.insert(record); // добавляем в поисковую таблицу
                return;
            }
        }

        // если все области полные - создаём новую
        int newId = getNewId();
        Region newRegion = new Region(newId, maxRegionCapacity);
        newRegion.addRecord(record);
        recordTree.insert(record); // добавляем в поисковую таблицу
        regions.insertLast(newRegion);
    }

    // получить новый ID для новой области
    private int getNewId() {
        int maxId = 0;
        for (Region r : regions) {
            if (r.getId() > maxId) maxId = r.getId();
        }
        return maxId + 1;
    }

    // получить список всех областей
    public AbstrDoubleList<Region> getRegions() {
        return regions;
    }

    // удаление записи по позиции (первый, последний, следующий, предыдущий)
    public void removeRecord(EnumPozice position) {
        for (Region r : regions) {
            if (!r.isEmpty()) {

                r.removeRecord(position);

                // если область пуста после удаления - удаляем её
                if (r.isEmpty()) {
                    regions.accessFirst();
                    while (regions.accessCurrent() != r) {
                        regions.accessNext();
                    }
                    regions.removeCurrent();
                }
                return;
            }
        }
        throw new IllegalStateException("Ни один регион не содержит записей для удаления");
    }

    // удаление конкретной записи
    public void removeRecord(Record record) {
        if (record == null) throw new IllegalArgumentException("Запись не может быть нулевой");

        for (Region r : regions) {
            if (r.containsRecord(record)) {
                r.removeRecord(record);             // удаляем из региона
                recordTree.remove(record.getId()); // удаляем из таблицы

                // если область пуста после удаления - удаляем её
                if (r.isEmpty()) {
                    regions.accessFirst();
                    while (regions.accessCurrent() != r) {
                        regions.accessNext();
                    }
                    regions.removeCurrent();
                }
                return;
            }
        }

        throw new IllegalStateException("Запись не найдена ни в одном регионе");
    }

    // очистка всех областей
    public void clear() {
        regions.clear();
        // очищаем таблицу записей
        recordTree = new RecordTable();
    }

    // вывод всех областей и их записей
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Region r : regions) {
            sb.append("Region ID: ").append(r.getId())
                    .append(" (").append(r.getCurrentCapacity()).append("/")
                    .append(r.getMaxCapacity()).append(")\n");
            sb.append(r.toString()).append("\n");
        }
        return sb.toString();
    }
}
