package project.model;

public class Record {
    private int id;
    private String name;

    public Record(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // геттеры
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Record{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}
