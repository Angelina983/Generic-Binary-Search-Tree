package project.model;

public enum EnumPozice {
    FIRST,      // первый элемент
    LAST,       // последний элемент
    NEXT,       // следующий элемент
    PREVIOUS    // предыдущий элемент
}