package project.model;

import project.list.AbstrDoubleList;

public class Region {

    private final int id;
    private final int maxCapacity;
    private int currentCapacity;

    private final AbstrDoubleList<Record> records = new AbstrDoubleList<>();

    public Region(int id, int maxCapacity) {
        this.id = id;
        this.maxCapacity = maxCapacity;
        this.currentCapacity = 0;
    }

    // геттеры
    public int getId() {
        return id;
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public int getCurrentCapacity() {
        return currentCapacity;
    }

    // состояниме региона
    public boolean isFull() {
        return currentCapacity >= maxCapacity;
    }

    public boolean isEmpty() {
        return currentCapacity == 0;
    }

    public boolean containsRecord(Record record) {
        if (record == null) return false;

        for (Record r : records) {
            if (r.equals(record)) return true;
        }
        return false;
    }

    // добавление
    public void addRecord(Record record) {
        if (record == null)
            throw new IllegalArgumentException("Запись не может быть нулевой");

        if (isFull())
            throw new IllegalStateException("Превышена пропускная способность региона");

        records.insertLast(record);
        currentCapacity++;
    }

    // удаление по позиции
    public Record removeRecord(EnumPozice pos) {
        if (records.isEmpty())
            return null;

        Record removed;

        switch (pos) {

            case FIRST:
                removed = records.removeFirst();
                break;

            case LAST:
                removed = records.removeLast();
                break;

            case NEXT:
                // removeNext() выбрасывает исключение, если next нет — ловим
                try {
                    removed = records.removeNext();
                } catch (Exception e) {
                    return null;
                }
                break;

            case PREVIOUS:
                try {
                    removed = records.removePrevious();
                } catch (Exception e) {
                    return null;
                }
                break;

            default:
                throw new IllegalArgumentException("Неизвестная enum позиция: " + pos);
        }

        currentCapacity--;
        return removed;
    }

    // удаление конкретной записи
    public boolean removeRecord(Record record) {
        if (record == null || records.isEmpty())
            return false;

        for (Record r : records) {
            if (r.equals(record)) {

                // Перед удалением — делаем найденный элемент текущим
                records.accessFirst();
                while (!records.accessCurrent().equals(r)) {
                    try {
                        records.accessNext();
                    } catch (Exception e) {
                        return false; // не нашли — не удаляем
                    }
                }

                records.removeCurrent();
                currentCapacity--;
                return true;
            }
        }

        return false;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Record r : records) {
            sb.append("   ").append(r).append("\n");
        }
        return sb.toString();
    }
}
