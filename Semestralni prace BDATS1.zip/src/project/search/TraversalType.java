package project.search;

public enum TraversalType {
    BREADTH,   // обход по ширине (BFS)
    DEPTH      // обход по глубине / in-order (DFS)
}
