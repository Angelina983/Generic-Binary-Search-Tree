package project.search;

import java.util.Iterator;
import java.util.NoSuchElementException;
import project.list.AbstrFifo;
import project.list.AbstrLifo;

/**
 * Generic Binary Search Tree (BST)
 * с хранением размера поддерева и операциями:
 * clear, isEmpty, find, insert, remove, select, rank, createIterator
 */
public class AbstrSearchTable<K extends Comparable<K>, V> {

    // Внутренний класс для узла дерева
    private class Node {
        K key;
        V value;
        Node left, right;
        int size;   // размер поддерева

        Node(K k, V v, int s) {
            key = k;
            value = v;
            size = s;
        }
    }

    private Node root;

    // очистка дерева
    public void clear() {
        root = null;
    }

    // проверка на пустоту
    public boolean isEmpty() {
        return root == null;
    }

    // поиск по ключу
    public V find(K key) {
        Node x = root;
        while (x != null) {
            int cmp = key.compareTo(x.key);
            if (cmp == 0) return x.value;
            x = cmp < 0 ? x.left : x.right;
        }
        return null;
    }

    // вставка ключ-значение
    public void insert(K key, V value) {
        root = insert(root, key, value);
    }

    private Node insert(Node x, K key, V val) {
        if (x == null) return new Node(key, val, 1);
        int cmp = key.compareTo(x.key);
        if (cmp < 0) x.left = insert(x.left, key, val);
        else if (cmp > 0) x.right = insert(x.right, key, val);
        else x.value = val;
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    // удаление по ключу
    public void remove(K key) {
        V existing = find(key);
        if (existing == null) return;
        root = remove(root, key);
    }

    private Node remove(Node x, K key) {
        if (x == null) return null;
        int cmp = key.compareTo(x.key);
        if (cmp < 0) x.left = remove(x.left, key);
        else if (cmp > 0) x.right = remove(x.right, key);
        else {
            if (x.left == null) return x.right;
            if (x.right == null) return x.left;
            Node t = x;
            Node m = min(t.right);
            m.right = deleteMin(t.right);
            m.left = t.left;
            x = m;
        }
        if (x != null) x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    // найти минимальный узел
    private Node min(Node x) {
        while (x.left != null) x = x.left;
        return x;
    }

    // удалить минимальный узел
    private Node deleteMin(Node x) {
        if (x.left == null) return x.right;
        x.left = deleteMin(x.left);
        x.size = 1 + size(x.left) + size(x.right);
        return x;
    }

    private int size(Node x) {
        return x == null ? 0 : x.size;
    }

    public int size() {
        return size(root);
    }

    // индекс на основе 1 (1 = наименьший)
    public V select(int k) {
        if (k < 1 || k > size()) throw new IllegalArgumentException("k вне диапазона");
        Node x = select(root, k);
        return x == null ? null : x.value;
    }

    private Node select(Node x, int k) {
        if (x == null) return null;
        int leftSize = size(x.left);
        if (k == leftSize + 1) return x;
        else if (k <= leftSize) return select(x.left, k);
        else return select(x.right, k - leftSize - 1);
    }

    // вернуть ранг ключа (кол-во меньших + 1)
    public int rank(K key) {
        return rank(root, key);
    }

    private int rank(Node x, K key) {
        if (x == null) return -1;
        int cmp = key.compareTo(x.key);
        if (cmp < 0) return rank(x.left, key);
        else if (cmp > 0) {
            int r = rank(x.right, key);
            if (r == -1) return -1;
            return 1 + size(x.left) + r;
        } else {
            return size(x.left) + 1;
        }
    }

    // создание итератора
    // BFS (ширина) или DFS/in-order (глубина)
    public Iterator<V> createIterator(TraversalType type) {
        if (type == TraversalType.BREADTH) {
            AbstrFifo<Node> fifo = new AbstrFifo<>();
            return new Iterator<V>() {
                {
                    if (root != null) fifo.add(root);  // вставка
                }

                @Override
                public boolean hasNext() {
                    return !fifo.isEmpty();       // проверка пустоты
                }

                @Override
                public V next() {
                    if (fifo.isEmpty()) throw new NoSuchElementException();
                    Node n = fifo.remove();            // удаление
                    if (n.left != null) fifo.add(n.left);
                    if (n.right != null) fifo.add(n.right);
                    return n.value;
                }
            };
        } else {
            AbstrLifo<Node> stack = new AbstrLifo<>();
            return new Iterator<V>() {
                Node cur = root;

                {
                    while (cur != null) {
                        stack.add(cur);          // вставка
                        cur = cur.left;
                    }
                }

                @Override
                public boolean hasNext() {
                    return !stack.isEmpty();     // проверка пустоты
                }

                @Override
                public V next() {
                    if (stack.isEmpty()) throw new NoSuchElementException();
                    Node n = stack.remove();      // удаление
                    V val = n.value;
                    Node r = n.right;
                    while (r != null) {
                        stack.add(r);        // вставка
                        r = r.left;
                    }
                    return val;
                }
            };
        }
    }
}
