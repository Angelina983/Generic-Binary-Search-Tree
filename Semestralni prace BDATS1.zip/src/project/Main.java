package project;

import project.ui.DataManagerGUI;

public class Main {
    public static void main(String[] args) {
        DataManagerGUI ui = new DataManagerGUI();
    }
}
