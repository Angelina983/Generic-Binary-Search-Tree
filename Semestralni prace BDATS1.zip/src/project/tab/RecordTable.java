package project.tab;

import project.model.Record;
import project.search.AbstrSearchTable;
import project.search.TraversalType;

import java.util.Iterator;

/**
 * RecordTable предоставляет операции: find/insert/remove/createIterator/select/rank
 */

public class RecordTable {
    private final AbstrSearchTable<Integer, Record> st = new AbstrSearchTable<>();

    // Найти запись по id
    public Record find(int id) {
        return st.find(id);
    }

    // Вставить запись
    public void insert(Record record) {
        st.insert(record.getId(), record);
    }

    // Удалить запись по id
    public void remove(int id) {
        st.remove(id);
    }

    // Создать итератор с заданным типом обхода
    public Iterator<Record> createIterator(TraversalType type) {
        return st.createIterator(type);
    }

    // Получить k-ую запись по порядку
    public Record select(int k) {
        return st.select(k);
    }

    // Получить ранг записи по id
    public int rank(int id) {
        return st.rank(id);
    }
}
