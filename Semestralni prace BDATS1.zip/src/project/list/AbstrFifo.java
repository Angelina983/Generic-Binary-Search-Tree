package project.list;

import java.util.Iterator;

public class AbstrFifo<T> {
    // Вспомогательный класс, использующий AbstrDoubleList
    private final AbstrDoubleList<T> list = new AbstrDoubleList<>();

    // Очистка списка
    public void clear() {
        list.clear();
    }

    // Проверка, пуст ли список
    public boolean isEmpty() {
        return list.isEmpty();
    }

    // Добавление элемента в конец списка
    public void add(T data) {
        list.insertLast(data);
    }

    // Удаление и возвращение первого элемента списка
    public T remove() {
        return list.removeFirst();
    }

    // Создание итератора для прохода по списку
    public Iterator<T> createIterator() {
        return list.iterator();
    }
}
