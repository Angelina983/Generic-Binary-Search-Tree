package project.list;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class AbstrDoubleList<T> implements IAbstrDoubleList<T> {
    // Внутренний класс, представляющий элемент списка
    private static class Node<T> {
        T data;
        Node<T> previous;
        Node<T> next;
        Node(T data) {
            this.data = data;
        }
    }

    private Node<T> first;
    private Node<T> last;
    private Node<T> current;

    @Override
    public void clear() {
        // Очистка списка
        first = last = current = null;
    }

    @Override
    public boolean isEmpty() {
        return first == null;
    }

    @Override
    public void insertFirst(T data) {
        // Вставка элемента в начало списка
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            first = last = current = newNode;
        } else {
            newNode.next = first;
            first.previous = newNode;
            first = newNode;
            current = newNode;
        }
    }

    @Override
    public void insertLast(T data) {
        // Вставка элемента в конец списка
        Node<T> newNode = new Node<>(data);
        if (isEmpty()) {
            first = last = current = newNode;
        } else {
            last.next = newNode;
            newNode.previous = last;
            last = newNode;
            current = newNode;
        }
    }

    @Override
    public void insertAfterCurrent(T data) {
        // Вставка элемента после текущего
        if (current == null) throw new NoSuchElementException("Список пуст");
        Node<T> newNode = new Node<>(data);
        newNode.next = current.next;
        newNode.previous = current;
        if (current.next != null) {
            current.next.previous = newNode;
        }
        current.next = newNode;
        current = newNode;
    }

    @Override
    public void insertBeforeCurrent(T data) {
        // Вставка элемента перед текущим
        if (current == null) throw new NoSuchElementException("Список пуст");
        Node<T> newNode = new Node<>(data);
        newNode.next = current;
        newNode.previous = current.previous;
        if (current.previous != null) {
            current.previous.next = newNode;
        } else {
            first = newNode;
        }
        current.previous = newNode;
        current = newNode;
    }

    @Override
    public T accessCurrent() {
        // Возвращает текущий элемент
        if (current == null) throw new NoSuchElementException("Список пуст");
        return current.data;
    }

    @Override
    public T accessFirst() {
        // Устанавливает текущим и возвращает первый элемент
        if (first == null) throw new NoSuchElementException("Список пуст");
        current = first;
        return current.data;
    }

    @Override
    public T accessLast() {
        // Устанавливает текущим и возвращает последний элемент
        if (last == null) throw new NoSuchElementException("Список пуст");
        current = last;
        return current.data;
    }

    @Override
    public T accessNext() {
        // Переход к следующему элементу
        if (current == null || current.next == null)
            throw new NoSuchElementException("Нет следующего элемента");
        current = current.next;
        return current.data;
    }

    @Override
    public T accessPrevious() {
        // Переход к предыдущему элементу
        if (current == null || current.previous == null)
            throw new NoSuchElementException("Нет предыдущего элемента");
        current = current.previous;
        return current.data;
    }

    @Override
    public T removeCurrent() {
        // Удаление текущего элемента и установка нового текущего на первый
        if (current == null) throw new NoSuchElementException("Список пуст");
        T data = current.data;

        if (current.previous != null) {
            current.previous.next = current.next;
        } else {
            first = current.next;
        }

        if (current.next != null) {
            current.next.previous = current.previous;
        } else {
            last = current.previous;
        }

        current = first;
        return data;
    }

    @Override
    public T removeFirst() {
        // Удаление первого элемента
        if (first == null) throw new NoSuchElementException("Список пуст");
        T data = first.data;
        if (first.next != null) {
            first = first.next;
            first.previous = null;
        } else {
            first = last = current = null;
        }
        current = first;
        return data;
    }

    @Override
    public T removeLast() {
        // Удаление последнего элемента
        if (last == null) throw new NoSuchElementException("Список пуст");
        T data = last.data;
        if (last.previous != null) {
            last = last.previous;
            last.next = null;
        } else {
            first = last = current = null;
        }
        current = first;
        return data;
    }

    @Override
    public T removeNext() {
        // Удаление следующего элемента после текущего
        if (current == null || current.next == null)
            throw new NoSuchElementException("Нет следующего элемента");
        current = current.next;
        return removeCurrent();
    }

    @Override
    public T removePrevious() {
        // Удаление предыдущего элемента перед текущим
        if (current == null || current.previous == null)
            throw new NoSuchElementException("Нет предыдущего элемента");
        current = current.previous;
        return removeCurrent();
    }

    @Override
    public Iterator<T> iterator() {
        // Простой итератор для прохода по списку
        return new Iterator<T>() {
            Node<T> currentNode = first;

            @Override
            public boolean hasNext() {
                return currentNode != null;
            }

            @Override
            public T next() {
                if (!hasNext()) throw new NoSuchElementException();
                T data = currentNode.data;
                currentNode = currentNode.next;
                return data;
            }
        };
    }
}