package project.list;

import java.util.Iterator;

public interface IAbstrDoubleList<T> extends Iterable<T> {
    void clear();                        // очистить список

    boolean isEmpty();                    // проверить, пустой ли список

    void insertFirst(T data);             // вставить элемент в начало

    void insertLast(T data);              // вставить элемент в конец

    void insertAfterCurrent(T data);      // вставить после текущего

    void insertBeforeCurrent(T data);     // вставить перед текущим

    T accessCurrent();                     // получить текущий элемент

    T accessFirst();                       // сделать первым текущим

    T accessLast();                        // сделать последним текущим

    T accessNext();                        // перейти к следующему элементу

    T accessPrevious();                    // перейти к предыдущему элементу

    T removeCurrent();                     // удалить текущий (и сделать первый текущим)

    T removeFirst();                       // удалить первый

    T removeLast();                        // удалить последний

    T removeNext();                        // удалить следующий после текущего

    T removePrevious();                    // удалить предыдущий перед текущим

    @Override
    Iterator<T> iterator();                // итератор для foreach
}
